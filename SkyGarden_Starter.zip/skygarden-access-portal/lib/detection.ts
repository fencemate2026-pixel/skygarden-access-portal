// Preview scenario helpers. The Pi's alarm outputs are authoritative in the uplink.
// PASS pulses alone cannot establish a per-entry count without an entry/reset signal.
export function foyerExceeded(count: number, allowance: number): boolean {
  if (!Number.isInteger(count) || count < 0 || !Number.isInteger(allowance) || allowance < 1) throw new Error("Invalid count or allowance");
  return count > allowance;
}
export function boomExceeded(seconds: number, threshold: number): boolean {
  if (!Number.isFinite(seconds) || seconds < 0 || !Number.isFinite(threshold) || threshold <= 0) throw new Error("Invalid duration or threshold");
  return seconds > threshold;
}
