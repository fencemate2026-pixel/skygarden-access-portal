import type { Metadata, Viewport } from "next";
import "./globals.css";
import "./balwyn-theme.css";
export const metadata: Metadata = {
  title: "Sky Garden | Magic Keys Detect",
  description: "Sky Garden foyer and LG boom detection portal by Magic Keys.",
  icons: { icon: "/favicon.svg" }, robots: { index: false, follow: false }
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#062846" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en-AU"><body>{children}</body></html>;
}
