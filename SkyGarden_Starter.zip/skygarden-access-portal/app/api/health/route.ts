export function GET() {
  return Response.json({ app: "skygarden-access-portal", status: "ok", mode: "preview", hardwareConnected: false }, {headers: {"Cache-Control": "no-store"}});
}
