"use client";
import Image from "next/image";
import Link from "next/link";
import { useState } from "react";
import { Activity, Bell, Building2, Camera, ChevronRight, Clock3, DoorOpen, LayoutDashboard, Menu, Radio, RotateCcw, Settings2, ShieldCheck, Users, X } from "lucide-react";
import { boomExceeded, foyerExceeded } from "@/lib/detection";

type View = "overview" | "events" | "detection" | "settings";
type Event = { id: string; location: string; message: string; alarm: boolean; time: string };
const nav = [
  {id:"overview",label:"Site overview",icon:LayoutDashboard},
  {id:"events",label:"Events & alerts",icon:Bell},
  {id:"detection",label:"Detection settings",icon:Settings2},
  {id:"settings",label:"System status",icon:Activity}
] as const;
const titles = { overview: "Site overview", events: "Events & alerts", detection: "Detection settings", settings: "System status" };

export default function Dashboard() {
  const [view,setView] = useState<View>("overview");
  const [mobile,setMobile] = useState(false);
  const [allowance,setAllowance] = useState(2);
  const [threshold,setThreshold] = useState(9);
  const [count,setCount] = useState(0);
  const [seconds,setSeconds] = useState(0);
  const [events,setEvents] = useState<Event[]>([]);
  const [filter,setFilter] = useState("all");
  const [feedback,setFeedback] = useState("");
  const alarmCount = events.filter(e=>e.alarm).length;
  function record(location: string, message: string, alarm: boolean) {
    setEvents(items=>[{ id: crypto.randomUUID(), location, message, alarm,
      time:new Intl.DateTimeFormat("en-AU",{hour:"2-digit",minute:"2-digit",second:"2-digit",timeZone:"Australia/Melbourne"}).format(new Date()) },...items].slice(0,50));
    setFeedback(alarm ? "Example alert recorded. No notification was sent." : "Example event recorded.");
  }
  const filtered = events.filter(e=>filter==="all" || e.alarm);
  function eventList() { return events.length ? <div className="event-list">{filtered.map(e=><div className="event-item" key={e.id}><span className={e.alarm?"event-icon alert":"event-icon"}>{e.alarm?<Bell size={18}/>:<Activity size={18}/>}</span><div><strong>{e.location}</strong><p>{e.message}</p></div><time>{e.time}</time><span className="tag">Example</span></div>)}{!filtered.length && <p>No example alerts recorded.</p>}</div> : <div className="empty"><Radio size={28}/><strong>Waiting for the first event</strong><p>Connect the SkyGarden devices to see live activity.<br/>You can explore the examples below in the meantime.</p></div>; }
  return <div className="control-portal skygarden-shell">
    <aside className={`control-sidebar ${mobile?"mobile-open":""}`}>
      <div className="portal-sidebar-header"><Image src="/magic-keys-logo-2026-on-dark.png" width={210} height={77} alt="Magic Keys" priority/><button className="mobile-close" aria-label="Close navigation" onClick={()=>setMobile(false)}><X/></button></div>
      <div className="site-identity"><Building2 size={23}/><div><strong>SKY GARDEN</strong><span>Glen Waverley</span></div></div>
      <p className="nav-label">DETECTION PORTAL</p>
      <nav aria-label="Main navigation">{nav.map(({id,label,icon:Icon})=><button key={id} className="portal-nav-button" data-active={view===id} aria-current={view===id?"page":undefined} onClick={()=>{setView(id);setMobile(false)}}><Icon/><span>{label}</span>{id==="events"&&alarmCount>0&&<span className="nav-count">{alarmCount}</span>}</button>)}</nav>
      <div className="sidebar-bottom"><div className="sidebar-status"><ShieldCheck size={22}/><strong>Detection & notification</strong><p>Foyer and LG boom monitoring</p></div><Image src="/rjl-commercial-logo-clear.png" width={130} height={57} alt="RJL Commercial" className="rjl-logo"/><small>Magic Keys Detect · v0.1</small></div>
    </aside>
    {mobile&&<button className="nav-scrim" aria-label="Close navigation" onClick={()=>setMobile(false)}/>}
    <div className="portal-workspace">
      <header className="topbar"><button className="mobile-toggle" aria-label="Open navigation" onClick={()=>setMobile(true)}><Menu/></button><div><span>MAGIC KEYS DETECT</span><strong>Sky Garden <ChevronRight size={15}/> {titles[view]}</strong></div><Link href="/login" className="operator"><span className="operator-avatar">SG</span><span>Operator sign in</span></Link></header>
      <div className="preview-banner"><Radio size={17}/><span><strong>Workspace preview</strong> · Devices and notifications are not connected. Examples reset when you reload.</span></div>
      <main className="workspace-content">
        <div className="workspace-title-row"><div><p className="eyebrow">SKY GARDEN · GLEN WAVERLEY</p><h1>{titles[view]}</h1><p>{view==="overview"?"Foyer and LG boom detection, together in one view.":view==="events"?"Review detections and alerts for both locations.":view==="detection"?"Explore the settings before site commissioning.":"Connection and commissioning status."}</p></div><span className="tag"><Clock3 size={14}/> Melbourne time</span></div>
        {view==="overview"&&<>
          <section className="summary-grid" aria-label="Summary"><article className="summary-card"><span><Building2 size={19}/> Monitored locations</span><strong>02</strong><small>Main foyer · LG boom</small></article><article className="summary-card"><span><Radio size={19}/> Devices connected</span><strong>0 / 2</strong><small>Awaiting commissioning</small></article><article className="summary-card"><span><Bell size={19}/> Example alerts</span><strong>{String(alarmCount).padStart(2,"0")}</strong><small>Current preview session</small></article><article className="summary-card"><span><Users size={19}/> Foyer mode</span><strong className="word-stat">Limited</strong><small>Allowance set at commissioning</small></article></section>
          <section className="monitor-grid" aria-label="Detection locations">
            <article className="monitor-card"><div className="monitor-heading"><DoorOpen/><div><h2>Main foyer</h2><span>Person detection · Limited Mode</span></div><span className="tag">Not connected</span></div><div className="monitor-image"><Image src="/foyer-concept.png" alt="Concept illustration of a glass foyer entrance with an overhead sensor" fill sizes="(max-width: 1000px) 100vw, 42vw" priority/><span>Concept image</span></div><div className="monitor-details"><div><small>People per entry</small><strong>To be confirmed</strong></div><div><small>Detection source</small><strong>Person detection device</strong></div></div><footer><span>Alert when the entry allowance is exceeded</span><button onClick={()=>setView("detection")}>View settings <ChevronRight size={16}/></button></footer></article>
            <article className="monitor-card"><div className="monitor-heading"><Camera/><div><h2>LG boom gate</h2><span>Arm-up duration monitoring</span></div><span className="tag">Not connected</span></div><div className="monitor-image"><Image src="/boom-concept.png" alt="Concept illustration of a basement boom barrier monitored by a standalone camera" fill sizes="(max-width: 1000px) 100vw, 42vw" priority/><span>Concept image</span></div><div className="monitor-details"><div><small>Alert threshold</small><strong>To be measured on site</strong></div><div><small>Detection source</small><strong>Standalone camera</strong></div></div><footer><span>Observe and alert · no gate-control connection</span><button onClick={()=>setView("detection")}>View settings <ChevronRight size={16}/></button></footer></article>
          </section>
          <section className="panel activity-panel"><div className="panel-heading"><div><h2>Recent activity</h2><small>Foyer and LG boom events</small></div><button className="text-button" onClick={()=>setView("events")}>View all events <ChevronRight size={16}/></button></div>{eventList()}</section>
        </>}
        {view==="events"&&<section className="panel"><div className="panel-heading"><div><h2>Event history</h2><small>Example records only in this preview</small></div><label className="filter-label">Show<select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">All events</option><option value="alerts">Alerts only</option></select></label></div>{eventList()}</section>}
        {(view==="overview"||view==="detection")&&<section className="panel"><div className="panel-heading"><div><h2>Explore a detection event</h2><small>Example settings only. These controls do not change equipment.</small></div><span className="tag">Preview</span></div><div className="simulator-grid"><div><h3><Users size={19}/> Foyer Limited Mode</h3><label>Example people allowance<input type="number" min={1} max={20} value={allowance} onChange={e=>setAllowance(Math.max(1,Math.min(20,Number(e.target.value)||1)))}/></label><div className="counter"><strong>{count}</strong><span>people in this entry</span></div><div className="button-row"><button className="primary-button" onClick={()=>{const next=count+1;setCount(next);record("Main foyer",`${next} people detected · allowance ${allowance}`,foyerExceeded(next,allowance));}}>Add a person</button><button className="secondary-button" onClick={()=>{setCount(0);setFeedback("A new example entry has started.")}}><RotateCcw size={15}/> New entry</button></div><p>Counts apply to one entry event, not total building occupancy.</p></div><div><h3><Camera size={19}/> LG boom monitoring</h3><label>Example threshold (seconds)<input type="number" min={1} max={120} value={threshold} onChange={e=>setThreshold(Math.max(1,Math.min(120,Number(e.target.value)||1)))}/></label><label>Example arm-up duration: {seconds} seconds<input type="range" min={0} max={60} value={seconds} onChange={e=>setSeconds(Number(e.target.value))}/></label><div className="button-row"><button className="primary-button" onClick={()=>record("LG boom gate",`${seconds}s arm-up time · ${threshold}s threshold`,boomExceeded(seconds,threshold))}>Check example</button></div><p>A longer opening flags a possible tailgate for review.</p></div></div><p className="feedback" role="status">{feedback || "Choose an example to see how an alert appears."}</p></section>}
        {view==="settings"&&<section className="panel"><div className="panel-heading"><h2>System readiness</h2><span className="tag">Setup required</span></div><div className="readiness-list">{[
          ["SkyGarden backend","Source prepared · dedicated Supabase project not connected"],
          ["Foyer device","Input-only agent prepared · electrical interface and device settings to verify"],
          ["LG boom camera","Camera timing and video integration to complete"],
          ["Alert recipients","Nominated recipients and delivery channels to configure"],
          ["Operator accounts","Separate SkyGarden sign-in to connect"],
          ["Fire alarm integration","Optional · assessment and agreed response required"]
        ].map(([label,status])=><div key={label}><strong>{label}</strong><span>{status}</span></div>)}</div></section>}
        <p className="scope-note"><ShieldCheck size={17}/> Detection and notification only. Existing access control and fire release remain independent.</p>
      </main>
    </div>
  </div>;
}
