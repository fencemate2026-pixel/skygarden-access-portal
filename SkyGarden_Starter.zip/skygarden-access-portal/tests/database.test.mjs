import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {PGlite} from '@electric-sql/pglite';

test('Postgres transaction, retry deduplication, rollback and site authorization',async()=>{
  const db=new PGlite();
  try{
    await db.exec(`create role anon; create role authenticated; create role service_role bypassrls;
      create schema auth; create table auth.users(id uuid primary key);
      create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;
      grant usage on schema public,auth to anon,authenticated,service_role;
      grant execute on function auth.uid() to authenticated;
      insert into auth.users values ('00000000-0000-0000-0000-000000000001'),('00000000-0000-0000-0000-000000000002');`);
    await db.exec(readFileSync(new URL('../supabase/schema/bootstrap.sql',import.meta.url),'utf8'));
    await db.exec(`update public.detect_devices set enabled=true;
      insert into public.detect_members values ('sky-garden','00000000-0000-0000-0000-000000000001');`);
    const event={seq:1,type:'TAILGATE',state:'ASSERT',input:'optex_tailgating_1',location:'Main foyer',occurredAt:1790500000};
    const ingest=events=>db.query('select public.ingest_detect_batch($1,$2::jsonb,$3::jsonb) as result',['skygarden-foyer-01',JSON.stringify(events),JSON.stringify({queueDepth:1})]);
    await db.exec('set role service_role');
    assert.deepEqual((await ingest([event])).rows[0].result,{accepted:[1]});
    assert.deepEqual((await ingest([event])).rows[0].result,{accepted:[1]});
    assert.equal((await db.query('select count(*)::int as n from public.detect_events')).rows[0].n,1);
    assert.equal((await db.query('select count(*)::int as n from public.detect_alert_outbox')).rows[0].n,1);
    await assert.rejects(ingest([{...event,seq:2},{...event,type:'MULTIPLE'}]),/Sequence reused/);
    assert.equal((await db.query('select count(*)::int as n from public.detect_events')).rows[0].n,1,'entire batch rolls back on conflict');
    await db.exec('reset role; set role authenticated');
    await db.query(`select set_config('request.jwt.claim.sub',$1,false)`,['00000000-0000-0000-0000-000000000002']);
    assert.equal((await db.query('select * from public.detect_events')).rows.length,0,'non-member cannot view site events');
    await db.query(`select set_config('request.jwt.claim.sub',$1,false)`,['00000000-0000-0000-0000-000000000001']);
    assert.equal((await db.query('select * from public.detect_events')).rows.length,1,'member sees its site');
    await assert.rejects(ingest([event]),/permission denied/,'operators cannot invoke device ingest');
    await assert.rejects(db.exec(`update public.detect_devices set enabled=false`),/permission denied/);
    await db.exec('reset role; set role anon');
    await assert.rejects(db.exec('select * from public.detect_events'),/permission denied/);
  }finally{await db.close();}
});
