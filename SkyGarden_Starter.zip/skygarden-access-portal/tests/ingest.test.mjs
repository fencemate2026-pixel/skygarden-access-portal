import test from 'node:test';
import assert from 'node:assert/strict';
import {createHmac} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {verifySignature} from '../supabase/functions/_shared/hmac.ts';
import {createIngestHandler} from '../supabase/functions/ingest/handler.ts';
import {foyerExceeded,boomExceeded} from '../lib/detection.ts';
const secret='s'.repeat(40), now=1790500000, id='skygarden-foyer-01';
const event={seq:1,type:'TAILGATE',state:'ASSERT',input:'optex_tailgating_1',location:'Main foyer',occurredAt:now};
function request(payload={deviceId:id,events:[event],heartbeat:null}, options={}) {
  const body=JSON.stringify(payload), ts=String(options.ts??now);
  return new Request('https://example.invalid/ingest',{method:'POST',headers:{'Content-Type':'application/json','X-MK-Device':id,'X-MK-Timestamp':ts,'X-MK-Signature':options.signature??createHmac('sha256',secret).update(`${ts}.${body}`).digest('hex')},body});
}
test('Python and WebCrypto agree on the committed signature vector',async()=>{
  const v=JSON.parse(readFileSync(new URL('fixtures/hmac_vector.json',import.meta.url)));
  assert.equal(await verifySignature(v.secret,String(v.timestamp),v.signature,new TextEncoder().encode(v.body),v.timestamp),true);
  assert.equal(await verifySignature(v.secret,String(v.timestamp),v.signature,new TextEncoder().encode(v.body+' '),v.timestamp),false);
});
test('unsigned, tampered, stale and mismatched-device batches never reach storage',async()=>{
  let calls=0;const handler=createIngestHandler({secretFor:()=>secret,now:()=>now,store:async()=>{calls++;return[1]}});
  for(const options of [{signature:'bad'},{signature:'0'.repeat(64)},{ts:now-301},{ts:now+301}]) assert.equal((await handler(request(undefined,options))).status,401);
  assert.equal((await handler(request({deviceId:'other',events:[event],heartbeat:null}))).status,400);
  assert.equal(calls,0);
});
test('acknowledgement is returned only after complete durable storage',async()=>{
  for(const store of [async()=>{throw new Error('offline')},async()=>[],async()=>[2],async()=>[1,1]]){
    const handler=createIngestHandler({secretFor:()=>secret,now:()=>now,store});
    const response=await handler(request());assert.equal(response.status,503);assert.equal((await response.json()).accepted,undefined);
  }
  const response=await createIngestHandler({secretFor:()=>secret,now:()=>now,store:async()=>[1]})(request());
  assert.equal(response.status,200);assert.deepEqual(await response.json(),{accepted:[1]});
});
test('invalid events and oversized payloads are rejected',async()=>{
  const handler=createIngestHandler({secretFor:()=>secret,now:()=>now,store:async()=>{throw new Error('must not write')}});
  for(const events of [[{...event,seq:1.5}],[event,event],[{...event,type:'OPEN_GATE'}],[{...event,type:'PASS',state:'ASSERT'}]])assert.equal((await handler(request({deviceId:id,events,heartbeat:null}))).status,400);
  assert.equal((await handler(request({deviceId:id,events:[],heartbeat:{large:'x'.repeat(270000)}}))).status,413);
});
test('empty heartbeat batches and timestamp boundary remain supported',async()=>{
  const handler=createIngestHandler({secretFor:()=>secret,now:()=>now,store:async()=>[]});
  assert.equal((await handler(request({deviceId:id,events:[],heartbeat:{queueDepth:0}},{ts:now-300}))).status,200);
});
test('preview rules distinguish at limit from above limit',()=>{
  assert.equal(foyerExceeded(2,2),false);assert.equal(foyerExceeded(3,2),true);
  assert.equal(boomExceeded(9,9),false);assert.equal(boomExceeded(9.1,9),true);
});
