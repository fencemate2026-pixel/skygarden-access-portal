export type DeviceEvent = { seq: number; type: "PASS"|"TAILGATE"|"MULTIPLE"|"SENSOR_ERROR"; state: "PULSE"|"ASSERT"|"CLEAR"; input: string; location: string; occurredAt: number; extra?: Record<string, unknown> };
export type Payload = { deviceId: string; events: DeviceEvent[]; heartbeat: Record<string, unknown>|null };
const object=(v: unknown): v is Record<string,unknown> => v!==null&&typeof v==="object"&&!Array.isArray(v);
const text=(v: unknown): v is string => typeof v==="string"&&v.length>0&&v.length<=160;
export function parsePayload(value: unknown, deviceId: string): Payload {
  if(!object(value)||value.deviceId!==deviceId||!Array.isArray(value.events)||value.events.length>100 || !(value.heartbeat===null||object(value.heartbeat))) throw new Error("Invalid envelope");
  const seen=new Set<number>();
  for(const e of value.events) {
    if(!object(e)||!Number.isSafeInteger(e.seq)||Number(e.seq)<1||seen.has(Number(e.seq)) || !["PASS","TAILGATE","MULTIPLE","SENSOR_ERROR"].includes(String(e.type)) || !text(e.input)||!text(e.location)||typeof e.occurredAt!=="number"||!Number.isFinite(e.occurredAt)||e.occurredAt<0||e.occurredAt>253402300799 || (e.extra!==undefined&&!object(e.extra))) throw new Error("Invalid event");
    if(e.type==="PASS" ? e.state!=="PULSE" : !["ASSERT","CLEAR"].includes(String(e.state))) throw new Error("Invalid event state");
    seen.add(Number(e.seq));
  }
  return value as unknown as Payload;
}
