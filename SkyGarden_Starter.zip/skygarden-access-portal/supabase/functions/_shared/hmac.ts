const encoder = new TextEncoder();
export const MAX_SKEW_SECONDS = 300;
export async function verifySignature(secret: string, timestamp: string, signature: string, body: Uint8Array, now = Math.floor(Date.now()/1000)): Promise<boolean> {
  if (!/^(0|[1-9][0-9]{0,12})$/.test(timestamp) || !/^[0-9a-f]{64}$/i.test(signature)) return false;
  const ts = Number(timestamp);
  if (!Number.isSafeInteger(ts) || Math.abs(now-ts)>MAX_SKEW_SECONDS || secret.length<32) return false;
  const prefix=encoder.encode(`${timestamp}.`), message=new Uint8Array(prefix.length+body.length);
  message.set(prefix); message.set(body,prefix.length);
  const key=await crypto.subtle.importKey("raw",encoder.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["verify"]);
  const signatureBytes = new Uint8Array(signature.match(/../g)!.map(x=>parseInt(x,16)));
  return crypto.subtle.verify("HMAC",key,signatureBytes,message);
}
