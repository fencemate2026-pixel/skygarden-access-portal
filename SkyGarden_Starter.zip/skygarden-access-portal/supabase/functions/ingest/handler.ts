import { verifySignature } from "../_shared/hmac.ts";
import { parsePayload, type Payload } from "../_shared/contract.ts";
export type IngestDependencies = { secretFor: (id: string)=>string|undefined; store: (payload:Payload)=>Promise<number[]>; now?:()=>number };
const MAX_BYTES=256*1024;
const response=(status:number,body:unknown)=>Response.json(body,{status,headers:{"Cache-Control":"no-store"}});
async function rawBody(req: Request): Promise<Uint8Array> {
  const reader=req.body?.getReader();
  if(!reader) throw new Error("Empty body");
  const chunks:Uint8Array[]=[]; let total=0;
  try {
    while(true){ const {done,value}=await reader.read(); if(done)break; total+=value.length; if(total>MAX_BYTES){await reader.cancel();throw new RangeError("Body too large");} chunks.push(value); }
  } finally {reader.releaseLock();}
  const result=new Uint8Array(total);let offset=0;for(const chunk of chunks){result.set(chunk,offset);offset+=chunk.length;}return result;
}
export function createIngestHandler(deps: IngestDependencies) {
  return async (req: Request): Promise<Response> => {
    if(req.method!=="POST")return response(405,{error:"Method not allowed"});
    if(req.headers.get("Content-Type")?.split(";")[0].trim().toLowerCase()!=="application/json")return response(415,{error:"JSON required"});
    const id=req.headers.get("X-MK-Device")??"", timestamp=req.headers.get("X-MK-Timestamp")??"", signature=req.headers.get("X-MK-Signature")??"";
    if(!/^[a-zA-Z0-9_-]{1,100}$/.test(id))return response(401,{error:"Authentication failed"});
    const secret=deps.secretFor(id);if(!secret)return response(401,{error:"Authentication failed"});
    let body:Uint8Array;
    try{body=await rawBody(req);}catch(e){return response(e instanceof RangeError?413:400,{error:"Invalid body"});}
    if(!await verifySignature(secret,timestamp,signature,body,deps.now?.()))return response(401,{error:"Authentication failed"});
    let payload:Payload;
    try{payload=parsePayload(JSON.parse(new TextDecoder("utf-8",{fatal:true}).decode(body)),id);}catch{return response(400,{error:"Invalid event envelope"});}
    try{
      const accepted=await deps.store(payload);
      const sent=payload.events.map(e=>e.seq);
      if(!Array.isArray(accepted)||accepted.length!==sent.length||accepted.some(s=>!Number.isSafeInteger(s)||!sent.includes(s))||new Set(accepted).size!==sent.length)throw new Error("Incomplete commit");
      return response(200,{accepted});
    }catch{return response(503,{error:"Storage unavailable; retain and retry the batch"});}
  };
}
