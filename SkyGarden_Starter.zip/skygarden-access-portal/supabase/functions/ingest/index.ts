import { createIngestHandler } from "./handler.ts";

// Server-only secrets. No Balwyn defaults and no service key in the frontend.
const url=Deno.env.get("SUPABASE_URL");
const key=Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
const secrets:Record<string,string>=JSON.parse(Deno.env.get("MKD_DEVICE_SECRETS_JSON")??"{}");
if(!url||!key)throw new Error("Backend environment is not configured");
const handler=createIngestHandler({
  secretFor: id=>Object.prototype.hasOwnProperty.call(secrets,id)?secrets[id]:undefined,
  store: async payload=>{
    const result=await fetch(`${url}/rest/v1/rpc/ingest_detect_batch`,{
      method:"POST",headers:{"Content-Type":"application/json",apikey:key,Authorization:`Bearer ${key}`},
      body:JSON.stringify({p_device_id:payload.deviceId,p_events:payload.events,p_heartbeat:payload.heartbeat}),
      signal:AbortSignal.timeout(10000)
    });
    if(!result.ok)throw new Error("Database commit failed");
    const data=await result.json();return data.accepted;
  }
});
Deno.serve(handler);
