-- Reviewed source schema. Apply ONLY to a new, dedicated SkyGarden project.
-- Generate a migration via the Supabase CLI when linking that new project.
begin;
create table public.detect_sites (
  id text primary key, name text not null, timezone text not null default 'Australia/Melbourne'
);
create table public.detect_members (
  site_id text not null references public.detect_sites(id),
  user_id uuid not null references auth.users(id),
  primary key (site_id,user_id)
);
create index detect_members_user on public.detect_members(user_id,site_id);
create table public.detect_devices (
  id text primary key, site_id text not null references public.detect_sites(id),
  location text not null, enabled boolean not null default false,
  last_seen_at timestamptz, heartbeat jsonb,
  unique(id,site_id)
);
create index detect_devices_site on public.detect_devices(site_id);
create table public.detect_events (
  device_id text not null, site_id text not null,
  seq bigint not null check(seq>0 and seq<=9007199254740991),
  type text not null check(type in ('PASS','TAILGATE','MULTIPLE','SENSOR_ERROR')),
  state text not null check(state in ('PULSE','ASSERT','CLEAR')),
  occurred_at timestamptz not null, received_at timestamptz not null default now(),
  payload jsonb not null, primary key(device_id,seq),
  foreign key(device_id,site_id) references public.detect_devices(id,site_id),
  check((type='PASS' and state='PULSE') or (type<>'PASS' and state in ('ASSERT','CLEAR')))
);
create index detect_events_site_time on public.detect_events(site_id,received_at desc);
create table public.detect_alert_outbox (
  device_id text not null, seq bigint not null, site_id text not null,
  status text not null default 'pending' check(status in ('pending','delivered','failed')),
  created_at timestamptz not null default now(), primary key(device_id,seq),
  foreign key(device_id,seq) references public.detect_events(device_id,seq),
  foreign key(site_id) references public.detect_sites(id)
);
create index detect_alert_pending on public.detect_alert_outbox(created_at) where status='pending';
create index detect_alert_site on public.detect_alert_outbox(site_id);

alter table public.detect_sites enable row level security;
alter table public.detect_members enable row level security;
alter table public.detect_devices enable row level security;
alter table public.detect_events enable row level security;
alter table public.detect_alert_outbox enable row level security;
revoke all on public.detect_sites,public.detect_members,public.detect_devices,public.detect_events,public.detect_alert_outbox from anon,authenticated;
grant select on public.detect_sites,public.detect_members,public.detect_devices,public.detect_events,public.detect_alert_outbox to authenticated;
grant all on public.detect_sites,public.detect_members,public.detect_devices,public.detect_events,public.detect_alert_outbox to service_role;
create policy own_memberships on public.detect_members for select to authenticated using (user_id=(select auth.uid()));
create policy member_sites on public.detect_sites for select to authenticated using (id in (select site_id from public.detect_members where user_id=(select auth.uid())));
create policy member_devices on public.detect_devices for select to authenticated using (site_id in (select site_id from public.detect_members where user_id=(select auth.uid())));
create policy member_events on public.detect_events for select to authenticated using (site_id in (select site_id from public.detect_members where user_id=(select auth.uid())));
create policy member_alerts on public.detect_alert_outbox for select to authenticated using (site_id in (select site_id from public.detect_members where user_id=(select auth.uid())));

-- SECURITY INVOKER: callable only by service_role after the edge function checks HMAC.
create function public.ingest_detect_batch(p_device_id text,p_events jsonb,p_heartbeat jsonb)
returns jsonb language plpgsql security invoker set search_path='' as $$
declare v_site text; e jsonb; existing jsonb; accepted jsonb='[]'::jsonb; seq_value bigint;
begin
  select site_id into v_site from public.detect_devices where id=p_device_id and enabled for update;
  if v_site is null then raise exception 'Unknown or disabled device'; end if;
  if jsonb_typeof(p_events)<>'array' or jsonb_array_length(p_events)>100 then raise exception 'Invalid batch'; end if;
  for e in select value from jsonb_array_elements(p_events) loop
    seq_value=(e->>'seq')::bigint;
    select payload into existing from public.detect_events where device_id=p_device_id and seq=seq_value;
    if found then
      -- A wiped/reinstalled Pi must not silently overwrite/reuse an acknowledged seq.
      if existing<>e then raise exception 'Sequence reused with different content'; end if;
    else
      insert into public.detect_events(device_id,site_id,seq,type,state,occurred_at,payload)
      values(p_device_id,v_site,seq_value,e->>'type',e->>'state',to_timestamp((e->>'occurredAt')::double precision),e);
      if e->>'state'='ASSERT' and e->>'type' in ('TAILGATE','MULTIPLE','SENSOR_ERROR') then
        insert into public.detect_alert_outbox(device_id,seq,site_id) values(p_device_id,seq_value,v_site);
      end if;
    end if;
    accepted=accepted||jsonb_build_array(seq_value);
  end loop;
  update public.detect_devices set last_seen_at=now(),heartbeat=coalesce(p_heartbeat,heartbeat) where id=p_device_id;
  return jsonb_build_object('accepted',accepted);
end;
$$;
revoke all on function public.ingest_detect_batch(text,jsonb,jsonb) from public,anon,authenticated;
grant execute on function public.ingest_detect_batch(text,jsonb,jsonb) to service_role;
insert into public.detect_sites(id,name) values('sky-garden','Sky Garden');
insert into public.detect_devices(id,site_id,location) values('skygarden-foyer-01','sky-garden','Main foyer');
commit;
