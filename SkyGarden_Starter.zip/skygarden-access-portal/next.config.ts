import type { NextConfig } from "next";
const config: NextConfig = {
  output: "standalone",
  poweredByHeader: false,
  async headers() {
    return [{ source: "/:path*", headers: [
      {key: "X-Content-Type-Options", value: "nosniff"},
      {key: "X-Frame-Options", value: "DENY"},
      {key: "Referrer-Policy", value: "same-origin"},
      {key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()"}
    ] }];
  }
};
export default config;
