# Signed ingest contract

The Pi posts to the dedicated SkyGarden project's `/functions/v1/ingest`:

```text
Content-Type: application/json
X-MK-Device: <device ID>
X-MK-Timestamp: <integer Unix seconds>
X-MK-Signature: hex(HMAC_SHA256(secret, timestamp + "." + raw body bytes))
```

The body is `{ "deviceId": "...", "events": [...], "heartbeat": null }`. The signature is verified against the original bytes before parsing. The maximum clock difference is 300 seconds, the body limit is 256 KiB and batches are limited to 100 events (agent example: 50). The configured device ID must match the header and be enabled in the database.

Events retain the supplied `seq`, `type`, `state`, `input`, `location`, `occurredAt` (Unix seconds), and optional `extra` fields. Accepted types are PASS/PULSE and TAILGATE, MULTIPLE or SENSOR_ERROR with ASSERT/CLEAR. The device's site comes from the provisioned device record, never the payload.

One SQL transaction records events and pending alert jobs, updates device health, and returns `{ "accepted": [1, 2] }`. Identical sequence replays are acknowledged without another alert job. A changed event under the same sequence rejects the entire batch. Database failures return an error without an acknowledgement; the Pi retains the batch.

## Deployment preparation

`supabase/config.toml` disables platform JWT checks for **ingest only** because the Pi uses HMAC instead. All requests must pass the handler's HMAC check. See [Supabase's signed webhook guidance](https://supabase.com/docs/guides/functions/auth).

Server environment:

- `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY`: supplied to the edge runtime, never the frontend.
- `MKD_DEVICE_SECRETS_JSON`: server-only JSON mapping the exact device ID to a high-entropy secret of at least 32 characters. Provision separately, never commit values.

Agent environment is documented in `pi-agent/.env.example`. Protect `/etc/magickeys-detect/agent.env` with restrictive permissions. Keep the state directory on persistent storage.

`supabase/schema/bootstrap.sql` is reviewed schema source, not an applied migration. No Supabase CLI or remote project was linked during creation. Once a **new SkyGarden project** is selected, use the CLI's current help and migration workflow to generate and apply the reviewed schema, run security advisors, then deploy the function. Do not run this against Balwyn.

RLS limits frontend reads to provisioned site members; anonymous clients have no table access. Only service_role can ingest or edit device/membership records. Notifications, stale-device scheduling and realtime subscriptions remain follow-on implementation.
