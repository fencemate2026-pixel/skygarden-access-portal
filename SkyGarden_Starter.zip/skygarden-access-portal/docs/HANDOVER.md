# Handover and next steps

## Current scope

Based on the Sky Garden Rev C proposal dated 26 September 2026:

- Main foyer: detect and notify using the person-detection device in Limited Mode. The allowance is per entry event, not whole-building occupancy.
- LG boom: camera-only observation of arm-up duration and video evidence. No connection to Vicinity's boom controller or reader.
- Door actuation, gate actuation and changes to fire release are not in the base scope. Fire integration is an optional later assessment.

## Agent source provenance

The supplied Claude material included `agent.py`, `uplink.py`, `outbox.py`, `support.py`, package entry points, the SkyGarden JSON example and a 31-test file. These were integrated and hardened. Original `config.py` and `inputs.py` were not supplied; this starter contains new implementations derived from the supplied configuration, interfaces and tests. Obtain the originals and compare before treating this as a continuation of Claude's exact implementation.

Changes from the snippets:

- Acknowledgements must contain only distinct integer sequence numbers from the sent batch. Booleans, fractional values, strings and unrelated sequences are rejected.
- Uplink redirects are disabled, response size is bounded, and server error bodies are not written to the audit log.
- Retry arithmetic stays bounded during prolonged outages.
- Outbox deletion is transactional. PASS eviction is counted in the heartbeat. The cap remains soft when only alarms/faults remain.
- Uptime uses the monotonic clock. Failed sender threads return a failing process exit status.
- Shutdown never closes the SQLite connection beneath a still-running sender or starts a concurrent final flush. Pending events survive shutdown.
- Log reinitialization closes old handlers; extra fields cannot replace the authoritative audit timestamp/level/message.
- The input monitor commits a transition only after durable event creation succeeds.

## Commissioning gaps

1. Confirm the exact person-detection model, documented output electrical characteristics, signal isolation, active polarity and minimum pulse widths. The supplied BCM pins are example assignments, not a wiring instruction or verified manufacturer recommendation.
2. Agree and configure the device's Limited Mode allowance, entry boundaries, direction and reset. The supplied PASS pulses have no entry/reset identity: summing them cannot reliably implement a per-entry allowance in the server. The backend records the device's TAILGATE/MULTIPLE outputs without inventing entry counts.
3. Complete camera arm-position timing and video capture for the LG boom. The current GPIO ingest contract is for the foyer only; boom examples in the UI are illustrative and do not represent an implemented camera adapter.
4. Provision a new Supabase project for SkyGarden, generate reviewed migrations, deploy ingestion, provision a unique secret per device and enable only commissioned devices. Configure operator membership and separate Auth before showing live data.
5. Build the notification worker with provider idempotency, recipient configuration, retry/lease handling and delivery status. Add a scheduled stale-device check and disk pressure monitoring.
6. Implement authenticated frontend data access, reconnect behaviour and realtime delivery. Configure retention and restricted video access.
7. Verify live lost-response replay, offline queue recovery, SD-card power interruption, clock drift, sensor faults and notifications reaching the nominated recipients. NTP is required for the 300-second signature window.
8. Choose and configure separate Azure hosting. This repo includes checks but no auto-deploy workflow or copied Balwyn Azure secrets.

## State and durability

SQLite WAL/FULL improves durability but does not guarantee survival of faulty storage. The 50,000-row threshold removes only oldest PASS records. Alarms can grow past the cap; monitor available disk space and `droppedPass`. After state-disk loss, assign a new device ID or perform an explicit sequence-recovery procedure. Do not restart sequence numbering under an old device identity. The backend rejects the same sequence with changed content.

HMAC authenticates the sender and bytes; it does not prove that a sensor count is correct. Acknowledgement means the event transaction committed, not that a notification reached a person.
