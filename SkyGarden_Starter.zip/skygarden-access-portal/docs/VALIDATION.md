# Validation record

Validated locally on 28 September 2026 (Australia/Sydney):

- Next.js production build: passed.
- TypeScript frontend and shared ingest handler checks: passed.
- Python compilation: passed.
- Pi-agent tests: **34 passed**, including the 31 user-supplied tests and three regression tests for strict acknowledgements, long outages and the soft outbox cap.
- JavaScript/Postgres tests: **7 passed**. Covers cross-language HMAC, tampered/expired signatures, invalid envelopes, storage errors, exact-limit behaviour, real PostgreSQL transaction rollback/deduplication, member isolation and denied anonymous/operator writes.
- The PostgreSQL test uses PGlite with explicit test roles/auth scaffolding. It does not constitute a managed Supabase deployment test.
- Lockfile portability: no local filesystem dependency references; `npm ci --offline --dry-run` resolved successfully. Local runtime checks used the available installed dependencies. A clean remote CI installation still needs to run.
- Desktop and mobile browser checks: dashboard renders, concept images load, adding three people creates the above-allowance example, alert filtering works, mobile navigation responds, no page errors and no horizontal overflow at 390px.

Not run: hosted GitHub Actions (remote repository not yet created), Deno runtime checks, actual Supabase deployment/advisors, GPIO/device hardware tests, power-loss tests, SMS/email delivery, camera integration or live authentication.

No production system was changed or deployed. See HANDOVER.md for commissioning work.
