# Source and asset notes

- Frontend visual reference: `fencemate2026-pixel/balwyn-high-access-portal` at `54b98abb7660902c2c0af2d4b5b512766e6d721b` (main when inspected). `app/balwyn-theme.css` is its corporate theme; the SkyGarden shell is a new implementation using that theme, with school-specific workflows omitted.
- Magic Keys 2026 logo assets were read from that exact commit. RJL transparent logo was copied from the available Balwyn source asset. No client crest, client photographs, credentials, school data or automation code was copied.
- Requirements: SkyGarden AntiTailgating Proposal Rev C, 26 September 2026.
- Pi agent/test contract: Claude source and test file provided by the user in this conversation. Original missing modules are identified in HANDOVER.md.
- `public/foyer-concept.png`: built-in image generation; generic modern apartment glass foyer with an overhead person sensor, dark metal, stone and planting, sapphire/charcoal lighting, no people/text/logos. Landscape 1536×1024.
- `public/boom-concept.png`: built-in image generation; generic underground car-park boom and standalone camera, low ceiling, sapphire/charcoal lighting, horizontal boom, no people/vehicles/text/logos. Landscape 1536×1024.
- Images are conceptual, not photographs of the actual SkyGarden site. The UI labels them accordingly.
- Supabase documentation consulted: https://supabase.com/docs/guides/functions/auth and https://supabase.com/docs/guides/database/postgres/row-level-security . Relevant changelog reviewed at https://supabase.com/changelog?types=breaking-change .
- GPIO software API reference: https://github.com/joan2937/lg . Hardware wiring and the person detector's electrical interface have not been verified.

All software and branding are intended for the user's private project. No open-source licence is assigned to RJL's project by this starter.
