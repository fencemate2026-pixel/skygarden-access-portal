# SkyGarden Access Portal / MagicKeys Detect

Independent SkyGarden starter. Intended private GitHub repository: `fencemate2026-pixel/skygarden-access-portal`. This is a new codebase with its own history, configuration and backend; it does not modify or connect to Balwyn.

## Included

- Next.js frontend using Balwyn's current navy navigation, white workspace and orange headings, with the shared Magic Keys/RJL branding.
- New foyer and underground boom concept images, labelled as illustrations rather than site photographs.
- Clearly labelled preview dashboard, event filtering and detection examples. Sign-in is intentionally unavailable until separate SkyGarden authentication is configured. No live data is represented by the examples.
- Input-only Python Pi agent, persistent SQLite outbox, signed HMAC uplink and JSON audit logging.
- Supabase `ingest` source and a transaction-based PostgreSQL schema, with device sequence deduplication and member-only read policies.
- Python, WebCrypto/HTTP-contract and PostgreSQL authorization tests, plus GitHub CI configuration.

## Run the frontend

Use Node 22.13+ and npm. The dependency versions and lockfile are pinned from the existing Balwyn frontend.

```sh
npm ci
npm run dev
```

Open `http://localhost:3000`. Preview data is held only in the current tab and resets on reload.

```sh
npm test
npm run build
npm run typecheck
```

## Run the agent tests (no hardware)

```sh
python3 -m pip install -r pi-agent/requirements-dev.txt
npm run test:agent
```

## What still needs connecting

This is a tested **starter**, not a commissioned detection service. Authentication, a dedicated Supabase project, live dashboard subscriptions, notification delivery, scheduled stale-device alerts, camera/video integration, production hosting and onsite hardware verification are not implemented/deployed end to end. The alert outbox stores pending work; it does **not** send SMS, email or push messages yet.

See [handover](docs/HANDOVER.md), [backend contract](docs/BACKEND.md), and [source notes](docs/SOURCES.md) before continuing. Never copy Balwyn's secrets, data, identity configuration or deployment workflows into this repo.
