"""Input-only GPIO and debounce monitor, reconstructed from the provided tests.

Electrical isolation, permitted voltage and pulse width need onsite verification.
"""
from __future__ import annotations
from typing import Protocol, Callable
import threading
from .config import InputSpec

class GpioBackend(Protocol):
    def claim_inputs(self, pins: list[int], pull_up: bool) -> None: ...
    def read(self, pin: int) -> int: ...
    def close(self) -> None: ...

class FakeBackend:
    def __init__(self, idle_level: int = 1):
        self._idle, self._pins = idle_level, {}
        self._lock = threading.Lock()
    def claim_inputs(self, pins: list[int], pull_up: bool) -> None:
        with self._lock:
            for pin in pins:
                self._pins.setdefault(pin, self._idle)
    def set_level(self, pin: int, level: int) -> None:
        if level not in (0, 1):
            raise ValueError("invalid input level")
        with self._lock:
            self._pins[pin] = level
    def read(self, pin: int) -> int:
        with self._lock:
            return self._pins.get(pin, self._idle)
    def close(self) -> None:
        pass

class LgpioBackend:
    def __init__(self, chip: int):
        import lgpio
        self._lg = lgpio
        self._handle = lgpio.gpiochip_open(chip)
    def claim_inputs(self, pins: list[int], pull_up: bool) -> None:
        flags = self._lg.SET_PULL_UP if pull_up else self._lg.SET_PULL_DOWN
        for pin in pins:
            self._lg.gpio_claim_input(self._handle, pin, flags)
    def read(self, pin: int) -> int:
        level = self._lg.gpio_read(self._handle, pin)
        if level not in (0, 1):
            raise OSError("GPIO input read failed")
        return level
    def close(self) -> None:
        self._lg.gpiochip_close(self._handle)

class InputMonitor:
    def __init__(self, backend: GpioBackend, specs: tuple[InputSpec, ...], pull_up: bool, callback: Callable):
        self._backend, self._specs, self._callback = backend, specs, callback
        self._lock = threading.Lock()
        self._states = {}
        backend.claim_inputs([s.bcm for s in specs], pull_up)
    def _active(self, spec):
        level = self._backend.read(spec.bcm)
        if level not in (0, 1):
            raise OSError("invalid GPIO input")
        return level == (0 if spec.active_level == "LOW" else 1)
    def prime(self, t_ms: float) -> None:
        with self._lock:
            for s in self._specs:
                active = self._active(s)
                if active and s.mode == "LEVEL":
                    self._callback(s, "ASSERT", t_ms, {"atStart": True})
                # An active PULSE at boot is not counted as a new passage.
                self._states[s.name] = {"stable": active, "candidate": active, "since": t_ms}
    def poll(self, t_ms: float) -> None:
        with self._lock:
            for s in self._specs:
                active, v = self._active(s), self._states[s.name]
                if active != v["candidate"]:
                    v["candidate"], v["since"] = active, t_ms
                if active != v["stable"] and t_ms - v["since"] >= s.debounce_ms:
                    # Commit stable state only after durable event creation succeeds.
                    if s.mode == "LEVEL":
                        self._callback(s, "ASSERT" if active else "CLEAR", t_ms, {})
                    elif active:
                        self._callback(s, "PULSE", t_ms, {})
                    v["stable"] = active
    def snapshot(self) -> dict:
        with self._lock:
            return {s.name: {"active": self._states.get(s.name, {}).get("stable"), "event": s.event} for s in self._specs}
