"""JSON audit logging and dependency-free systemd notifications."""
from __future__ import annotations
import json
import logging
import logging.handlers
import os
import socket
import time
from typing import Any

class _JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        extra = getattr(record, "audit", None)
        entry = dict(extra) if isinstance(extra, dict) else {}
        # The audit payload cannot overwrite authoritative timestamp/level/message.
        entry.update(ts=time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime(record.created)), level=record.levelname, msg=record.getMessage())
        return json.dumps(entry, separators=(",", ":"), default=str)

def build_logger(state_dir: str, name: str = "magickeys-detect") -> logging.Logger:
    os.makedirs(state_dir, exist_ok=True)
    log = logging.getLogger(name)
    log.setLevel(logging.INFO)
    for handler in list(log.handlers):
        log.removeHandler(handler)
        handler.close()
    fh = logging.handlers.RotatingFileHandler(os.path.join(state_dir, "audit.log"), maxBytes=5*1024*1024, backupCount=5)
    sh = logging.StreamHandler()
    for handler in (fh, sh):
        handler.setFormatter(_JsonFormatter())
        log.addHandler(handler)
    log.propagate = False
    return log

def audit(log: logging.Logger, msg: str, level: int = logging.INFO, **fields: Any) -> None:
    log.log(level, msg, extra={"audit": fields})

def sd_notify(state: str) -> bool:
    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return False
    if addr.startswith("@"):
        addr = "\0" + addr[1:]
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM) as s:
            s.connect(addr)
            s.sendall(state.encode("utf-8"))
        return True
    except OSError:
        return False

def cpu_temp_c() -> float | None:
    try:
        with open("/sys/class/thermal/thermal_zone0/temp", encoding="ascii") as fh:
            return round(int(fh.read().strip())/1000.0, 1)
    except (OSError, ValueError):
        return None
