"""Input-only configuration validation, reconstructed from the supplied contract/tests.

BCM assignments below are software examples, not manufacturer-approved wiring.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import json
import os
from urllib.parse import urlparse
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

class ConfigError(ValueError):
    pass

@dataclass(frozen=True)
class InputSpec:
    name: str
    bcm: int
    active_level: str
    debounce_ms: int
    event: str
    mode: str

@dataclass(frozen=True)
class SiteConfig:
    site_id: str
    site_name: str
    timezone: str
    device_id: str
    location: str
    gpio_chip: int
    pull: str
    poll_ms: int
    inputs: tuple[InputSpec, ...]
    batch_max: int
    heartbeat_seconds: int

@dataclass(frozen=True)
class Env:
    ingest_url: str
    device_secret: str = field(repr=False)
    config_path: str
    state_dir: str
    gpio_backend: str

def _interlock(value):
    if isinstance(value, dict):
        for key, child in value.items():
            normal = key.lower().replace("_", "").replace("-", "")
            if any(x in normal for x in ("output", "relay", "unlock", "actuator")) or normal == "pulsems":
                raise ConfigError(f"{key} is not permitted in this input-only agent")
            if any(x in normal for x in ("secret", "password", "token", "hmackey", "apikey")):
                raise ConfigError(f"secret-like key {key} must be kept in environment")
            _interlock(child)
    elif isinstance(value, list):
        for child in value:
            _interlock(child)

def _object(value, keys, label):
    if not isinstance(value, dict) or set(value) != set(keys):
        raise ConfigError(f"{label}: expected only {', '.join(keys)}")
    return value

def _text(value, label):
    if not isinstance(value, str) or not value.strip() or len(value) > 160:
        raise ConfigError(f"invalid {label}")
    return value

def _integer(value, lo, hi, label):
    if type(value) is not int or not lo <= value <= hi:
        raise ConfigError(f"{label} must be an integer from {lo} to {hi}")
    return value

def parse_config(raw: dict) -> SiteConfig:
    _interlock(raw)
    raw = _object(raw, ("schemaVersion", "site", "device", "gpio", "uplink", "heartbeatSeconds"), "config")
    if raw["schemaVersion"] != "1.0.0":
        raise ConfigError("unsupported schemaVersion")
    site = _object(raw["site"], ("id", "name", "timezone"), "site")
    device = _object(raw["device"], ("id", "location"), "device")
    gpio = _object(raw["gpio"], ("chip", "pull", "pollMs", "inputs"), "gpio")
    uplink = _object(raw["uplink"], ("batchMax",), "uplink")
    tz = _text(site["timezone"], "timezone")
    try:
        ZoneInfo(tz)
    except ZoneInfoNotFoundError as exc:
        raise ConfigError("unknown timezone") from exc
    poll = _integer(gpio["pollMs"], 1, 1000, "pollMs")
    if gpio["pull"] not in ("UP", "DOWN"):
        raise ConfigError("pull must be UP or DOWN")
    if not isinstance(gpio["inputs"], list) or not 1 <= len(gpio["inputs"]) <= 16:
        raise ConfigError("expected 1 to 16 inputs")
    pins, names, specs = set(), set(), []
    for item in gpio["inputs"]:
        i = _object(item, ("name", "bcm", "activeLevel", "debounceMs", "event", "mode"), "input")
        pin = _integer(i["bcm"], 0, 27, "bcm")
        if pin in (0, 1, 2, 3, 14, 15):
            raise ConfigError(f"BCM {pin} is reserved")
        if pin in pins:
            raise ConfigError(f"BCM {pin} used twice")
        name = _text(i["name"], "input name")
        if name in names:
            raise ConfigError("input name used twice")
        pins.add(pin); names.add(name)
        debounce = _integer(i["debounceMs"], 1, 10000, "debounceMs")
        if debounce < poll:
            raise ConfigError("debounceMs shorter than pollMs")
        if i["activeLevel"] not in ("LOW", "HIGH") or i["mode"] not in ("LEVEL", "PULSE"):
            raise ConfigError("invalid activeLevel or mode")
        if i["event"] not in ("TAILGATE", "MULTIPLE", "SENSOR_ERROR", "PASS"):
            raise ConfigError("unknown event type")
        if (i["event"] == "PASS") != (i["mode"] == "PULSE"):
            raise ConfigError("PASS must use PULSE; alarms must use LEVEL")
        specs.append(InputSpec(name,pin,i["activeLevel"],debounce,i["event"],i["mode"]))
    return SiteConfig(_text(site["id"], "site id"),_text(site["name"], "site name"),tz,
        _text(device["id"], "device id"),_text(device["location"], "location"),
        _integer(gpio["chip"],0,16,"chip"),gpio["pull"],poll,tuple(specs),
        _integer(uplink["batchMax"],1,100,"batchMax"),_integer(raw["heartbeatSeconds"],5,3600,"heartbeatSeconds"))

def load_config(path: str) -> SiteConfig:
    with open(path, encoding="utf-8") as source:
        return parse_config(json.load(source))

def load_env(values=None) -> Env:
    e = os.environ if values is None else values
    url = e.get("MKD_INGEST_URL", "")
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.fragment or parsed.query:
        raise ConfigError("MKD_INGEST_URL must be an https URL without credentials, query or fragment")
    secret = e.get("MKD_DEVICE_SECRET", "")
    if len(secret) < 32:
        raise ConfigError("MKD_DEVICE_SECRET must contain at least 32 characters")
    backend = e.get("MKD_GPIO_BACKEND", "lgpio")
    if backend not in ("lgpio", "fake"):
        raise ConfigError("invalid GPIO backend")
    config = e.get("MKD_CONFIG_PATH", "/etc/magickeys-detect/site.json")
    state = e.get("MKD_STATE_DIR", "/var/lib/magickeys-detect")
    if not os.path.isabs(config) or not os.path.isabs(state):
        raise ConfigError("config and state paths must be absolute")
    return Env(url,secret,config,state,backend)
