"""Signed raw-byte HMAC uplink; only strict acknowledgements can remove events."""
from __future__ import annotations
import hashlib
import hmac
import json
import math
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

USER_AGENT = "magickeys-detect-agent/1.0"

def sign(secret: str, timestamp: int, body: bytes) -> str:
    return hmac.new(secret.encode("utf-8"), str(timestamp).encode("ascii") + b"." + body, hashlib.sha256).hexdigest()

@dataclass
class SendResult:
    ok: bool
    status: int
    accepted: list[int]
    error: str | None

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Never forward signed site data to an unexpected destination.
        return None

class Uplink:
    def __init__(self, url: str, device_id: str, secret: str, timeout_s: float = 15.0):
        self._url, self._device_id, self._secret, self._timeout = url, device_id, secret, timeout_s
        self._opener = urllib.request.build_opener(_NoRedirect())

    def send(self, events: list[dict[str, Any]], heartbeat: dict[str, Any] | None, now: float | None = None) -> SendResult:
        payload = {"deviceId": self._device_id, "events": events, "heartbeat": heartbeat}
        body = json.dumps(payload, separators=(",", ":"), allow_nan=False).encode("utf-8")
        ts = int(now if now is not None else time.time())
        req = urllib.request.Request(self._url, data=body, method="POST", headers={
            "Content-Type": "application/json", "User-Agent": USER_AGENT,
            "X-MK-Device": self._device_id, "X-MK-Timestamp": str(ts),
            "X-MK-Signature": sign(self._secret, ts, body)})
        try:
            with self._opener.open(req, timeout=self._timeout) as resp:
                status, raw = resp.status, resp.read(65537)
        except urllib.error.HTTPError as exc:
            # Backend response bodies may contain sensitive internals; do not log them.
            return SendResult(False, exc.code, [], f"HTTP {exc.code}")
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            return SendResult(False, 0, [], f"network: {exc}")
        try:
            if not 200 <= status < 300 or len(raw) > 65536:
                raise ValueError("unexpected status or oversized response")
            data = json.loads(raw)
            accepted = data["accepted"]
            sent = {e["seq"] for e in events}
            if not isinstance(accepted, list) or any(type(s) is not int or s < 1 for s in accepted):
                raise ValueError("accepted must contain positive integers")
            if len(accepted) != len(set(accepted)) or not set(accepted).issubset(sent):
                raise ValueError("unexpected or duplicate sequence acknowledgement")
        except (ValueError, TypeError, AttributeError, KeyError) as exc:
            return SendResult(False, status, [], f"bad response body: {exc}")
        missing = sent - set(accepted)
        if missing:
            return SendResult(False, status, accepted, f"backend did not confirm seqs {sorted(missing)}")
        return SendResult(True, status, accepted, None)

class Backoff:
    """2 seconds doubling to a ceiling, with bounded arithmetic at any failure count."""
    def __init__(self, base: float = 2.0, ceiling: float = 300.0):
        if not math.isfinite(base) or not math.isfinite(ceiling) or not 0 < base <= ceiling:
            raise ValueError("invalid backoff")
        self._base, self._ceiling, self._fails, self._delay = base, ceiling, 0, 0.0
    def fail(self) -> float:
        self._fails += 1
        self._delay = self._base if self._fails == 1 else min(self._ceiling, self._delay * 2)
        return self._delay
    def reset(self) -> None:
        self._fails, self._delay = 0, 0.0
    @property
    def failures(self) -> int:
        return self._fails
