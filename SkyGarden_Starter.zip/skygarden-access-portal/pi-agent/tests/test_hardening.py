import io
import json
from unittest.mock import patch
from detect_agent.uplink import Uplink, Backoff
from detect_agent.outbox import Outbox

class Response(io.BytesIO):
    status = 200

def test_uplink_never_acknowledges_unsent_or_coerced_sequences():
    uplink = Uplink('https://example.invalid/ingest','device','s'*40)
    for accepted in ([2], [True], [1.0], ['1'], [1,1], None):
        with patch.object(uplink._opener,'open',return_value=Response(json.dumps({'accepted':accepted}).encode())):
            result=uplink.send([{'seq':1,'type':'PASS'}],None)
            assert not result.ok and result.accepted==[]

def test_backoff_survives_long_outage():
    backoff=Backoff()
    for _ in range(2000):
        assert backoff.fail()<=300
    assert backoff.failures==2000
    backoff.reset()
    assert backoff.fail()==2

def test_alarm_only_outbox_soft_cap_and_pass_drop_counter(tmp_path,monkeypatch):
    from detect_agent import outbox
    monkeypatch.setattr(outbox,'MAX_ROWS',2)
    ob=Outbox(str(tmp_path))
    try:
        for _ in range(3):ob.put({'type':'TAILGATE'},1)
        ob.put({'type':'PASS'},1)
        assert ob.depth()==3
        assert ob.dropped_pass()==1
        assert all(e['type']=='TAILGATE' for e in ob.peek(10))
    finally:ob.close()
